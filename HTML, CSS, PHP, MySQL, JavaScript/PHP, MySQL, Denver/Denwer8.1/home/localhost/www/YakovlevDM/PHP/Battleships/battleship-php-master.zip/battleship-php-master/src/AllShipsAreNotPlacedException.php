<?php

namespace Battleship;

class AllShipsAreNotPlacedException extends \Exception
{
}
