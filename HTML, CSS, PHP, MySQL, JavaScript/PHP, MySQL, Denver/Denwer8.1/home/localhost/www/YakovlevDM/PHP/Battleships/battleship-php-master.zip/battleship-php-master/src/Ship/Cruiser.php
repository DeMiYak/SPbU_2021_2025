<?php

namespace Battleship\Ship;

class Cruiser extends Ship
{
    const ID = 3;
    const SIZE = 3;
}
