<?php

namespace Battleship\Ship;

class Submarine extends Ship
{
    const ID = 4;
    const SIZE = 3;
}
