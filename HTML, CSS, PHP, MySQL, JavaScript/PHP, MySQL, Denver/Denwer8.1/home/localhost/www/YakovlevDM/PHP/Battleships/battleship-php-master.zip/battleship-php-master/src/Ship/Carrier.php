<?php

namespace Battleship\Ship;

class Carrier extends Ship
{
    const ID = 1;
    const SIZE = 5;
}
