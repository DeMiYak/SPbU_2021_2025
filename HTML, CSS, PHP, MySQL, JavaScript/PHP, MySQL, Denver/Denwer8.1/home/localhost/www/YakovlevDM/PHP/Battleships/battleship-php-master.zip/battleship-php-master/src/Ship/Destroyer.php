<?php

namespace Battleship\Ship;

class Destroyer extends Ship
{
    const ID = 5;
    const SIZE = 2;
}
