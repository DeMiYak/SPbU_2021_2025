<?php

namespace Battleship;

class ShipAlreadyPlacedException extends \Exception
{
}
