<?php

namespace Battleship\Ship;

class Battleship extends Ship
{
    const ID = 2;
    const SIZE = 4;
}
