#include <iostream>
#include "math2_test.h"
using namespace std;
int main()
{
    test_sign();
    test_sqrt();
    return 0;
}
