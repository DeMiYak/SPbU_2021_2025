struct node;
typedef struct node node;

typedef int element_t;

