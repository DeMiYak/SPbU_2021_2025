#include<iostream>
#include<cmath>
#include"Queue.h"

int main()
{
//    queue q1();
//    cout << q1.isEmpty();
    return 0;
}
