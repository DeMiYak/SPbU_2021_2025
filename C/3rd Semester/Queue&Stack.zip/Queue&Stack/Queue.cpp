#include"Queue.h"
#include<cmath>

////void queue::isEmpty ();
////void queue::Push(size_t k);
////T queue::Pop();
////void queue::List();
////void queue::Add();
////T queue::GetFront();


