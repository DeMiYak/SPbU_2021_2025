//
// Created by vadim on 18.02.2022.
//

#ifndef LAB14_1_ARRAYINTERACT_H
#define LAB14_1_ARRAYINTERACT_H

int *IntArrayRead(int *array, size_t n);

void IntArrayPrint(const int *array, size_t n);

size_t DeleteEvenNumbers(int *array, size_t size);

#endif //LAB14_1_ARRAYINTERACT_H
