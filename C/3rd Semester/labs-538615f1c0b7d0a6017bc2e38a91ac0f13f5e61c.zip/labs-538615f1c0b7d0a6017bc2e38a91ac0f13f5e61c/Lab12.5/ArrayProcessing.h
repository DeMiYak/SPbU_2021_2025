//
//
//

#ifndef LAB12_5_ARRAYPROCESSING_H
#define LAB12_5_ARRAYPROCESSING_H

#include <stddef.h>

#define N 100

size_t GetLineWithMaxSum(double array[N][N], size_t n, size_t m);

#endif //LAB12_5_ARRAYPROCESSING_H
