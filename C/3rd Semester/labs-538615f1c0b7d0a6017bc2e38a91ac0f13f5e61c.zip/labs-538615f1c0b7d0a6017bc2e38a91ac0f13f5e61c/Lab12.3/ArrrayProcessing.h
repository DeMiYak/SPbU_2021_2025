//
//
//

#ifndef LAB12_3_ARRRAYPROCESSING_H
#define LAB12_3_ARRRAYPROCESSING_H

#include <stddef.h>

size_t DeleteEvenNumbers(int array[], size_t size);

#endif //LAB12_3_ARRRAYPROCESSING_H
