//
//
//

#ifndef LAB12_2_ARRAYPROCESSING_H
#define LAB12_2_ARRAYPROCESSING_H

#include <stddef.h>

size_t GetCountSwapsSign(const int array[], size_t size);

size_t GetMaxMonotonyOfArray(const int array[], size_t size);

int GetSecondMax(const int array[], size_t size);

#endif //LAB12_2_ARRAYPROCESSING_H
