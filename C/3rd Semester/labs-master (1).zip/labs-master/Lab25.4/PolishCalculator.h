//
// Created by vadim on 08.04.2022.
//

#ifndef LAB25_4_POLISHCALCULATOR_H
#define LAB25_4_POLISHCALCULATOR_H

#include "stack.h"

int Calculate(Stack *stack, char *operation);

#endif //LAB25_4_POLISHCALCULATOR_H
