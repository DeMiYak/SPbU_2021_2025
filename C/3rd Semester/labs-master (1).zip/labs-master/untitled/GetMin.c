//
// Created by Сергей on 12.11.2021.
//

#include "GetMin.h"
