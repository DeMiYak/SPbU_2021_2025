//
// Created by vadim on 18.03.2022.
//

#ifndef LAB18_1_STRTOARR_H
#define LAB18_1_STRTOARR_H

#include <stddef.h>

size_t ToArr(char *str, char *arr[100]);

#endif //LAB18_1_STRTOARR_H
