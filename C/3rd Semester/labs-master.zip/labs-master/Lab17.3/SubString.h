//
// Created by vadim on 04.03.2022.
//

#ifndef LAB17_3_SUBSTRING_H
#define LAB17_3_SUBSTRING_H

void SubStr(char *s, char *newS, int n, int m);

#endif //LAB17_3_SUBSTRING_H
