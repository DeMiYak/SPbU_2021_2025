//
// Created by vadim on 04.03.2022.
//

#ifndef LAB17_1_DELETESPACE_H
#define LAB17_1_DELETESPACE_H

void DeleteSpace(char *s);

#endif //LAB17_1_DELETESPACE_H
