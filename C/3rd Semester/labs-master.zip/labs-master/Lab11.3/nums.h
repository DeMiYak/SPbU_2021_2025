//
// Created by on 22.10.2021.
//

#ifndef LAB11_3_NUMS_H
#define LAB11_3_NUMS_H

void NumPrint(int n, int p);

void RecNumPrintRevers(int n, int p);

void RecNumPrint(int n, int p);

#endif //LAB11_3_NUMS_H
