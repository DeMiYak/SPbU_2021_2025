#include <math.h>
#include "r32m.h"

double rnnorm ()
{
 static int ind = 1;
 static double next;
 double x, y, s, t;

 ind = !ind;
 if ( ind )
  return ( next );
 else
 {
  do  {
   x = 2.0*rnunif() - 1.0;
   y = 2.0*rnunif() - 1.0;
   s = x*x + y*y;
  }  while ( s >= 1.0 );
  t = -2.0*log(s)/s;
  s = sqrt(t);
  next = y*s;
  return ( x*s );
 }
}