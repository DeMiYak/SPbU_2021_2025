#include <math.h>
#include "r32m.h"

double rnexp ()
{
 double rnunif ();
 return( - log( rnunif () ) );
}
