#include <math.h>
#include "r32m.h"
double rnexp ()
{
 extern double rnunif ();
 double  q [] =
  { 0.6931472,0.9333737,0.9888778,0.9984959,
    0.9998293,0.9999833,0.9999986,0.9999999,1.0 };
 double t = 0.0, u, v, umin;
 double *pq, *pqm;
// int l;

 pq = &q[0]; pqm = pq;
 u = rnunif ();
 while ( u < 0.5 )
 {
   t += *pq;
   /*printf ( " u = %10.5f \n", u );*/
   u = u + u;
 }
 u = u + u - 1.0;
 if ( u  >= *pq )
 {
  umin = rnunif ();
  for ( pqm = ++pq; ; pqm++ )
  {
   v = rnunif ();
   if ( v < umin )  umin = v;
   if ( u < *pqm )  return ( t+umin*(*pq) );
  }
 }
 else
  return ( t+u );
}
