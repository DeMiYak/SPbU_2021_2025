﻿#include"Distribution.h"

/// 
/// 1. Гипергеометрическое распределение 
/// 
/// 2. Построение графика зависимости мощности критерия от объёма
/// выборки при заданном уровне значимости и заданной альтернативе

/// <summary>
/// 1. Задавать параметры распределения, метод моделирования, объем выборки.
/// 2. Моделировать выборку(два метода).
/// 3. Изображать гистограмму на фоне теоретического распределения.Выдавать значение chi - square, число
/// степеней свободы(d.f. - degree of freedom) и пороговый уровень значимости(p - level).
/// 4. Получать выборку p-levels. Для этого задавать параметры распределения, которое моделируется,
/// параметры распределения, на согласие с которым проверяется гипотеза, и число повторов.Если это
/// одни и те же параметры распределения, то выдавать, какой истинный уровень значимости
/// соответствует заданному уровню значимости.Если это разные распределения, то выдавать, какая
/// мощность у критерия с заданным уровнем значимости против данной альтернативы.
/// 5. Изображать эмпирическую функцию распределения выборки p - levels на фоне теоретической ф.р. (т.е.,
/// функции распределения равномерного на[0, 1] распределения).
/// </summary>
/// <returns></returns>
int main()
{
    Test(IT);
    // a = 25, b = 30, k = 20
    random_device rd, rdAlt;
    int a, b, k;
    int n = 100, len = 10000;
    cin >> a >> b >> k;
    /*vector<double> sample = Hypergeometric_distribution(a, b, k);
    cout << endl << endl;
    for (int i = 0; i <= k; i++) {
        cout << "p" << i << ":\t" << sample[i] << '\n';
    }*/
    
    
    //cout << endl << inverse_transform(a, b, k, rd) << endl;
    //cout << endl << bernoulli_distribution(a, b, k, rd) << endl;

    // test_modelling
    HGDistribution HG(a, b, k, rd);
    /*  
    -Тестировать функции моделирования можно, например, так: вывести несколько первых реализаций
        датчика случайных чисел и несколько первых реализаций для моделируемого распределения.Затем, следуя
        алгоритму(а не тексту функции), сосчитать, какой должна быть реализация.
        */ 
    printf("%-10s|%s\n", "Inverse", "Bernoulli");
    for (int i = 0; i < 100; i++) {
        printf("%-10d|%d\n", HG.Inverse_Transform(), HG.Bernoulli_Distribution());
    }

    // For Bernoulli

    /*- Для тестирования правильности применения хи - квадрата, имеет смысл вывести теоретические и
        эмпирические частоты до объединения интервалов, затем после объединения интервалов, а также число
        степеней свободы, статистику критерия и p - level.Сумма теоретических и эмпирических частот всегда
        должна быть равна объему выборки.*/

    vector<int> sample = Generate_Sample(BD, n, HG);
    vector<int> freq = Count_Frequency(sample, HG.Get_K());
    const vector<double> tp = Theory_Prob(HG);
    vector<double> tf = Theory_Frequency(tp, n);
    vector<pair<double, int>> m_f = Chi_Square_Merge(tf, freq);
    double chi = Chi_Square(m_f);
    int dof = DOF(m_f);
    double p_level = pChi(chi, dof);

    int f_s = 0;
    double tf_s = 0;
    printf("%-s\n%-10s|%s\n", "Frequency", "Empiric", "Theoretical");
    for (int i = 0; i <= k; i++) {
        printf("%-10d|%.5lf\n", freq[i], tf[i]);
        f_s += freq[i];
        tf_s += tf[i];
    }
    printf("\n%-30s%d\n%-30s%.6lf\n", "Sample Volume: ", n, "Chi-Square: ", chi);
    printf("%-30s%d\n%-30s%.6lf\n", "Degree of Freedom: ", dof, "P-level: ", p_level);
    printf("%-30s%d\n%-30s%.6lf\n", "Empiric Frequency: ", f_s, "Theoretical Frequency: ", tf_s);

    //-Дальнейшей проверкой правильности будет близость гистограмм моделируемого распределения и
    //    выборки, а также не очень большие и не очень маленькие значения критерия хи - квадрат(если вы уже
    //        будете уверены, что в моделировании у вас ошибок нет, то эти же самые характеристики будут служить
    //        тестом для правильности построения гистограммы и вычисления критерия). Математическое ожидание для
    //    случайной величины с распределением хи - квадрат равно числу степеней свободы, т.е.реализации должны
    //    колебаться вокруг числа степеней свободы.Естественно, самой сильной проверкой будет равномерное
    //    распределение p - levels.

    printf("\n%-s\n", "Distribution when H1 = H0");

    vector<double> p_distr(20);
    for (int i = 0; i < len; i++) {
        double p_level = P_Value(BD, n, HG, HG);
        // Это распределение должно получиться равномерным, если проверяем нулевую гипотезу
        p_distr[floor(p_level / 0.05)]++;
    }

    // Комментарий: выводить частоты m_f
    /*printf("%-s\n%-10s|%s\n", "Frequency", "Empiric", "Theoretical");
    for(int i = 0; i < m_f.size(); i++) {
        printf("%-10d|%.6lf\n", m_f[i].second, m_f[i].first);
    }*/

    P_Distribution(p_distr);

    printf("\n%-s\n%-10s|%s\n", "p-value < alpha", "alpha", "#(p-value)");
    for (int i = 0; i < 20; i++) {
        printf("%-10.2lf|%.3lf\n", 0.05 * (i + 1), p_distr[i]);
    }


    //- Проверку гипотез удобно реализовать так : у вас в программе существует понятие основной(нулевой) и
    //    альтернативных гипотез(в данном случае нулевая и альтернативная гипотезы отличаются разными
    //        значениями параметров заданного распределения).Можно всегда моделировать распределение согласно
    //    альтернативной гипотезе и проверять на соответствие нулевой гипотезе(т.е.теоретические частоты всегда
    //        вычисляются на основе параметров из нулевой гипотезы).Если вы формально делаете альтернативную
    //    гипотезу равной нулевой, то распределение p - levels должно быть равномерным и на его основе можно
    //    смотреть, насколько истинная вероятность ошибки I рода отличается от заданного уровня значимости.Если
    //    альтернативная гипотеза отличается от нулевой, то распределение P - levels показывает, чему равна
    //    мощность критерия против заданной альтернативы при заданных уровнях значимости.

    HGDistribution HGAlt(a + 1, b-2, k, rdAlt);
    vector<double> p_distrAlt(20);

    printf("\n%-s\n%-s\n%-s", "Distribution for", "H0: a = a0, b = b0;", "H1: a = a0 + 1, b = b0 - 2");
    for (int i = 0; i < len; i++) {
        double p_level = P_Value(BD, n, HG, HGAlt);
        p_level = floor(p_level / 0.05);
        if (p_level == 20) p_level--;
        // Это распределение должно получиться равномерным, если проверяем нулевую гипотезу
        p_distrAlt[p_level]++;
    }

    P_Distribution(p_distrAlt);
    // Отсюда получаем мощность критерия для H1
    printf("\n%-s\n%-10s|%s\n", "p-value < alpha", "alpha", "#(p-value)");
    for (int i = 0; i < 20; i++) {
        printf("%-10.2lf|%.3lf\n", 0.05 * (i + 1), p_distrAlt[i]);
    }

    printf("\n%-s", "Second H1 distribution");
    
    random_device rdAlt2;
    HGDistribution HGAlt2(a - 5, b + 15, k, rdAlt2);
    for (int i = 0; i < 20; i++)
        p_distrAlt[i] = 0;
 
    for (int i = 0; i < len; i++) {
        double p_level = P_Value(BD, n, HG, HGAlt2);
        p_level = floor(p_level / 0.05);
        if (p_level == 20) p_level--;
        // Это распределение должно получиться равномерным, если проверяем нулевую гипотезу
        p_distrAlt[p_level]++;
    }

    P_Distribution(p_distrAlt);
    // Отсюда получаем мощность критерия для H1
    printf("\n%-s\n%-10s|%s\n", "p-value < alpha", "alpha", "#(p-value)");
    for (int i = 0; i < 20; i++) {
        printf("%-10.2lf|%.3lf\n", 0.05 * (i + 1), p_distrAlt[i]);
    }
    
    
    
    /*
    Построение графика зависимости мощности критерия от объёма выборки при
    заданном уровне значимости и заданной альтернативе
    */

    //random_device rdAlter, rdOrig;
    //int oa = 25, ob = 50, ok = 20;
    //int aa = oa-1, ab = ob+1, ak = ok;
    //HGDistribution HGOrig(oa, ob, ok, rdOrig);

    //// Уровень значимости
    //double alpha = 0.13;
    //// Число повторов
    //int lim = 3000;
    //// Альтернатива
    //HGDistribution HGAlter(aa, ab, ak, rdAlter);
    //printf("\n\n%-s%lf\n", "Alpha: ", alpha);
    //printf("%-s%c%d%c%d%c%d%c\n", "Original: ", '(',oa, ',',ob, ',',ok, ')');
    //printf("%-s%c%d%c%d%c%d%c\n", "Alternative: ", '(', aa, ',', ab, ',', ak, ')');
    //printf("%-15s|%s\n", "Sample Volume", "Criterion Power");
    //for (int i = 0; i <= 10; i++) {
    //    int n = 100 + 50 * i;
    //    double criteria_power = 0;
    //    for (int j = 0; j < lim; j++) {
    //        vector<int> sample = Generate_Sample(BD, n, HGAlter);
    //        vector<int> freq = Count_Frequency(sample, HGAlter.Get_K());
    //        // Так как верна альтернативная гипотеза,
    //        // то по ней выстраиваем теоретическое распределение
    //        // а затем проверяем, является ли верной гипотеза
    //        const vector<double> tp = Theory_Prob(HGOrig);
    //        vector<double> tf = Theory_Frequency(tp, n);
    //        vector<pair<double, int>> m_f = Chi_Square_Merge(tf, freq);
    //        double chi = Chi_Square(m_f);
    //        int dof = DOF(m_f);
    //        double p_level = pChi(chi, dof);
    //        if (alpha <= p_level) criteria_power++;
    //    }
    //    criteria_power /= lim;
    //    criteria_power = 1 - criteria_power;
    //    printf("%-15d|%.6lf\n", n, criteria_power);
    //}

    
    // Ошибка второго рода: P_H1(H0 неверно принята);
    // Мощность критерия: P_H1(H0 верно отвергнута);

    // For inverse_transform
    cout << endl << endl << "Inverse_transform test" << endl;
    Test(IT);
    return 0;
    
}