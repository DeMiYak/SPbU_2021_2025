#include"vector.h"

template<typename T>
void myvector<T>::push_back(T value)
{

}

template<typename T>
inline T myvector<T>::back() const
{
	return vec[len - 1];
}
