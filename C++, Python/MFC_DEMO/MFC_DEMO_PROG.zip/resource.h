﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MFCDEMO.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_MFCDEMOTYPE                 130
#define ID_WINDOW_MANAGER               131
#define IDR_THEME_MENU                  200
#define ID_SET_STYLE                    201
#define ID_VIEW_APPLOOK_WIN_2000        205
#define ID_VIEW_APPLOOK_OFF_XP          206
#define ID_VIEW_APPLOOK_WIN_XP          207
#define ID_VIEW_APPLOOK_OFF_2003        208
#define ID_VIEW_APPLOOK_VS_2005         209
#define ID_VIEW_APPLOOK_VS_2008         210
#define ID_VIEW_APPLOOK_OFF_2007_BLUE   215
#define ID_VIEW_APPLOOK_OFF_2007_BLACK  216
#define ID_VIEW_APPLOOK_OFF_2007_SILVER 217
#define ID_VIEW_APPLOOK_OFF_2007_AQUA   218
#define ID_VIEW_APPLOOK_WINDOWS_7       219
#define IDS_EDIT_MENU                   306
#define ID_MODEL                        310
#define ID_PLEVEL                       312
#define ID_CRITVOL                      313
#define IDC_WHBALL                      1001
#define IDC_BLBALL                      1002
#define IDC_PICKNUM                     1003
#define IDC_BERNMET                     1004
#define IDC_INVMET                      1005
#define IDC_SAMVOL                      1008
#define IDC_PL_SAMVOL                   1009
#define IDC_PL_REPNUM                   1010
#define IDC_PL_H0_PICKNUM               1011
#define IDC_PL_H0_BLBALL                1012
#define IDC_PL_H0_WHBALL                1013
#define IDC_PL_H1_WHBALL                1014
#define IDC_PL_H1_BLBALL                1015
#define IDC_PL_H1_PICKNUM               1016
#define IDC_PL_INV                      1017
#define IDC_PL_BERN                     1018
#define IDC_CV_TO_SV                    1019
#define IDC_CV_CRITNUM_SV               1019
#define IDC_CV_FROM_SV                  1020
#define IDC_CV_INTRVL_SV                1021
#define IDC_CV_SLVL                     1022
#define IDC_CV_H1_PICKNUM               1023
#define IDC_CV_H1_BLBALL                1024
#define IDC_CV_H1_WHBALL                1025
#define IDC_CV_H0_BLBALL                1026
#define IDC_CV_H0_PICKNUM               1027
#define IDC_CV_H0_WHBALL                1028
#define IDC_CV_INV                      1029
#define IDC_CV_BERN                     1030
#define IDC_CV_REPNUM                   1032
#define ID_DIALOG_MODELLING             32771
#define ID_DIALOG_MODELLING32772        32772
#define ID_BUTTON32773                  32773
#define ID_DIALOG_MODELLING32774        32774
#define ID_DIALOG_PARAMETERS            32775
#define ID_BUTTON32776                  32776
#define ID_DIALOG_PARAMETER             32777
#define ID_DIALOG_PARAMETERS32778       32778
#define ID_PL_MODELLING                 32780
#define ID_PL_PARAMETERS                32781
#define ID_P_MODELLING                  32782
#define ID_P_PARAMETERS                 32783
#define ID_CV_PARAMETERS                32784
#define ID_CV_MODELLING                 32785
#define ID_POW_MODELLING                32786
#define ID_POW_PARAMETERS               32787

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        314
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
